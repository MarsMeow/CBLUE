

## CBLUE:

### website: 
https://tianchi.aliyun.com/cblue

### documents：
https://tianchi.aliyun.com/dataset/dataDetail?dataId=95414

### paper:
https://arxiv.org/abs/2106.08087

Citation:

```
@article{zhang2021cblue,
title={CBLUE: A Chinese Biomedical Language Understanding Evaluation Benchmark},
author={Ningyu Zhang and Mosha Chen and Zhen Bi and Xiaozhuan Liang and Lei Li and Xin Shang and Kangping Yin and Chuanqi Tan and Jian Xu and Fei Huang and Luo Si and Yuan Ni and Guotong Xie and Zhifang Sui and Baobao Chang and Hui Zong and Zheng Yuan and Linfeng Li and Jun Yan and Hongying Zan and Kunli Zhang and Buzhou Tang and Qingcai Chen},  
journal={arXiv preprint arXiv:2106.08087},
year={2021}
}
```

If you have used the specified dataset, please also note the related papers:  

```
# CMeEE:

@book{2021Building,
  title={Building a Pediatric Medical Corpus: Word Segmentation and Named Entity Annotation},
  author={ Zan, H.  and  Li, W.  and  Zhang, K.  and  Ye, Y.  and  Sui, Z. },
  publisher={Chinese Lexical Semantics},
  year={2021}
}

# CMeIE:

@book{2020CMeIE,
  title={CMeIE: Construction and Evaluation of Chinese Medical Information Extraction Dataset},
  author={ Guan, T.  and  Zan, H. and Zhou, X. and Xu, H. and K Zhang},
  publisher={Natural Language Processing and Chinese Computing, 9th CCF International Conference, NLPCC 2020, Zhengzhou, China, October 14–18, 2020, Proceedings, Part I},
  year={2020}
}

# CHIP-CTC:

@article{DBLP:journals/midm/ZongYZLZ21,
  author    = {Hui Zong and
               Jinxuan Yang and
               Zeyu Zhang and
               Zuofeng Li and
               Xiaoyan Zhang},
  title     = {Semantic categorization of Chinese eligibility criteria in clinical
               trials using machine learning methods},
  journal   = {{BMC} Medical Informatics Decis. Mak.},
  volume    = {21},
  number    = {1},
  pages     = {128},
  year      = {2021},
  url       = {https://doi.org/10.1186/s12911-021-01487-w},
  doi       = {10.1186/s12911-021-01487-w},
  timestamp = {Wed, 28 Apr 2021 17:11:53 +0200},
  biburl    = {https://dblp.org/rec/journals/midm/ZongYZLZ21.bib},
  bibsource = {dblp computer science bibliography, https://dblp.org}
}

# MedDG:

@article{liu2020meddg,
      title={MedDG: A Large-scale Medical Consultation Dataset for Building Medical Dialogue System}, 
      author={Wenge Liu and Jianheng Tang and Jinghui Qin and Lin Xu and Zhen Li and Xiaodan Liang},
      year={2020},
      journal={arXiv preprint arXiv:2010.07497}
}

# IMCS:

@inproceedings{2018Task,
  title={Task-oriented Dialogue System for Automatic Diagnosis},
  author={ Wei, Z.  and  Liu, Q.  and  Peng, B.  and  Tou, H.  and X Dai},
  booktitle={Proceedings of the 56th Annual Meeting of the Association for Computational Linguistics (Volume 2: Short Papers)},
  year={2018},
}

@inproceedings{2019Enhancing,
  title={Enhancing Dialogue Symptom Diagnosis with Global Attention and Symptom Graph},
  author={X Lin and X He and Chen, Q. and Tou, H. and Chen, T.},
  booktitle={Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing and the 9th International Joint Conference on Natural Language Processing (EMNLP-IJCNLP)},
  year={2019},
}

@article{liao2020taskoriented,
  title={Task-oriented Dialogue System for Automatic Disease Diagnosis via Hierarchical Reinforcement Learning},
  author={ Liao, K.  and  Liu, Q.  and  Wei, Z.  and  Peng, B.  and  Chen, Q.  and  Sun, W.  and  Huang, X. },
  journal={arXiv preprint arXiv:2004.14254},  
  year={2020},
}
```

### baseline github:
https://github.com/CBLUEbenchmark/CBLUE, 欢迎star-fork-watch


## 钉钉交流群：
钉钉群号：34187610, 打榜过程中的问题均可在群里第一时间得到答复。


